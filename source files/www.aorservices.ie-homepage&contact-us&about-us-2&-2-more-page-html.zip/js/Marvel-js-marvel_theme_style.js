jQuery(document).ready(function( $ ) { 
   $('.marvel_counter .et_pb_circle_counter').data("bar-bg-color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_blurb_1 .et_pb_image_wrap .et-pb-icon.et-pb-icon-circle').css("background-color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_blurb_2 .et_pb_image_wrap .et-pb-icon').css("color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_blurb_3 .et_pb_image_wrap .et-pb-icon').css("color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_blurb_icon_right .et_pb_image_wrap .et-pb-icon').css("color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_bar_counter .et_pb_image_wrap .et-pb-icon.et-pb-icon-circle').css("background-color",marvelthemestyle.divi_marvel_theme_color);
   $('.marvel_bar_counter .et_pb_counter_amount').css("background-color",marvelthemestyle.divi_marvel_theme_color);
});
